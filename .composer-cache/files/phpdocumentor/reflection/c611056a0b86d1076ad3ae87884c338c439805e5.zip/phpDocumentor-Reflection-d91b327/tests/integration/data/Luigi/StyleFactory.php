<?php
/**
 * This file is part of phpDocumentor.
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @copyright 2010-2018 Mike van Riel<mike@phpdoc.org>
 * @license   http://www.opensource.org/licenses/mit-license.php MIT
 * @link      http://phpdoc.org
 */

namespace Luigi;

use Luigi\Pizza\PizzaComponentFactory;

final class StyleFactory extends PizzaComponentFactory
{
    public function getPrice()
    {
    }

    protected function calculatePrice()
    {
    }
}
